import type { InsightApiResponse, RequestContext, SimulationApiResponse } from "../types/contracts";

const API_BASE = process.env.NEXT_PUBLIC_API_BASE ?? "http://localhost:8000";

export async function fetchInsight(payload: RequestContext): Promise<InsightApiResponse> {
  const response = await fetch(`${API_BASE}/api/v1/insights`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    throw new Error(`Insight request failed: ${response.status}`);
  }

  return response.json() as Promise<InsightApiResponse>;
}

export async function fetchSimulation(payload: RequestContext): Promise<SimulationApiResponse> {
  const response = await fetch(`${API_BASE}/api/v1/simulations`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    throw new Error(`Simulation request failed: ${response.status}`);
  }

  return response.json() as Promise<SimulationApiResponse>;
}
