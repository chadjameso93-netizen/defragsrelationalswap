from typing import Literal, Optional
from pydantic import BaseModel, Field

DataConfidence = Literal["exact", "partial", "unknown"]
RelationshipType = Literal[
    "parent", "child", "sibling", "partner", "colleague", "friend", "extended_family", "other"
]
RequestedMode = Literal["insight", "simulation", "phrasing", "timing"]
ConfidenceLevel = Literal["low", "medium", "high"]
Tone = Literal["calm", "neutral", "soft", "direct"]


class PersonRef(BaseModel):
    id: str
    name: str
    birth_date: Optional[str] = None
    birth_time: Optional[str] = None
    birth_location: Optional[str] = None
    data_confidence: DataConfidence


class TargetPersonRef(PersonRef):
    relationship_type: RelationshipType


class RelationshipRef(BaseModel):
    id: Optional[str] = None
    type: Optional[RelationshipType] = None
    strength: Optional[float] = Field(default=None, ge=0, le=1)


class FamilyContextPerson(BaseModel):
    id: str
    name: str
    relationship_type: str


class EventItem(BaseModel):
    timestamp: str
    type: Literal["interaction", "conflict", "withdrawal", "repair", "conversation", "decision", "other"]
    description: str
    tags: list[str] = []


class RequestContext(BaseModel):
    user: PersonRef
    target_person: Optional[TargetPersonRef] = None
    relationship: Optional[RelationshipRef] = None
    family_context: list[FamilyContextPerson] = []
    recent_events: list[EventItem]
    user_request: str
    requested_mode: RequestedMode
    draft_phrase: Optional[str] = None
    preferred_tone: Optional[Tone] = None


class StructuredSynthesis(BaseModel):
    user_experience: str
    other_experience: str
    dynamic_between: str
    timing_assessment: str
    help_needed: str
    confidence_level: ConfidenceLevel


class Insight(BaseModel):
    what_may_be_happening: str
    what_it_may_be_causing: str
    what_to_try_next: list[str] = Field(min_length=1, max_length=3)
    tone: Tone


class PatternCandidate(BaseModel):
    name: str
    confidence: ConfidenceLevel


class ProofObject(BaseModel):
    evidence_used: list[str]
    pattern_candidates: list[PatternCandidate]
    timing_notes: list[str]
    uncertainty_notes: list[str]
    confidence_reason: str


class SimulationBody(BaseModel):
    likely_tension_points: list[str]
    possible_openings: list[str]
    phrasing_options: list[str] = Field(min_length=1, max_length=3)
    timing_options: list[str]
    confidence_level: ConfidenceLevel


class InsightApiResponse(BaseModel):
    structured_synthesis: StructuredSynthesis
    insight: Insight
    proof: ProofObject


class SimulationApiResponse(BaseModel):
    structured_synthesis: StructuredSynthesis
    simulation: SimulationBody
    proof: ProofObject
