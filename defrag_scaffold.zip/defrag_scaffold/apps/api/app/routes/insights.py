from fastapi import APIRouter
from app.models.contracts import RequestContext, InsightApiResponse

router = APIRouter(prefix="/api/v1/insights", tags=["insights"])


@router.post("", response_model=InsightApiResponse)
def create_insight(payload: RequestContext) -> InsightApiResponse:
    # Placeholder implementation for scaffold only.
    return InsightApiResponse(
        structured_synthesis={
            "user_experience": "The user may be feeling pressure and looking for clarity.",
            "other_experience": "The other person may not feel ready to engage directly.",
            "dynamic_between": "A request-and-withdraw pattern may be forming.",
            "timing_assessment": "Recent events suggest the topic may currently carry pressure.",
            "help_needed": "timing + phrasing",
            "confidence_level": "medium",
        },
        insight={
            "what_may_be_happening": "The topic may be carrying more pressure than the original issue itself.",
            "what_it_may_be_causing": "That pressure may be making one person push for clarity while the other creates distance.",
            "what_to_try_next": [
                "Pause briefly to lower tension.",
                "Name the feeling underneath the request.",
                "Choose a shorter, more contained time to revisit it.",
            ],
            "tone": "calm",
        },
        proof={
            "evidence_used": [e.description for e in payload.recent_events],
            "pattern_candidates": [{"name": "request_withdraw_pattern", "confidence": "medium"}],
            "timing_notes": ["Recent frequency suggests elevated pressure."],
            "uncertainty_notes": ["Motivation remains uncertain without more context."],
            "confidence_reason": "The repeated interaction pattern is visible, but the internal reasons remain unclear.",
        },
    )
