from fastapi import APIRouter
from app.models.contracts import RequestContext, SimulationApiResponse

router = APIRouter(prefix="/api/v1/simulations", tags=["simulations"])


@router.post("", response_model=SimulationApiResponse)
def create_simulation(payload: RequestContext) -> SimulationApiResponse:
    return SimulationApiResponse(
        structured_synthesis={
            "user_experience": "The user may be seeking clarity and wanting to avoid friction.",
            "other_experience": "The other person may be experiencing pressure around the topic.",
            "dynamic_between": "A repeated request-and-distance pattern may be present.",
            "timing_assessment": "This may be a better moment for a softer opening than a direct push.",
            "help_needed": "simulation",
            "confidence_level": "medium",
        },
        simulation={
            "likely_tension_points": ["Direct pressure on the unresolved topic."],
            "possible_openings": ["Acknowledge pressure first, then narrow the ask."],
            "phrasing_options": [
                "I want to make this easier to talk about, not heavier.",
                "Can we find a small next step instead of solving everything now?",
            ],
            "timing_options": ["Delay slightly", "Use a brief scheduled check-in"],
            "confidence_level": "medium",
        },
        proof={
            "evidence_used": [e.description for e in payload.recent_events],
            "pattern_candidates": [{"name": "request_withdraw_pattern", "confidence": "medium"}],
            "timing_notes": ["Recent interaction density suggests active pressure."],
            "uncertainty_notes": ["Simulation is exploratory and not predictive."],
            "confidence_reason": "The simulation is grounded in the observed pattern, but future behavior is not certain.",
        },
    )
