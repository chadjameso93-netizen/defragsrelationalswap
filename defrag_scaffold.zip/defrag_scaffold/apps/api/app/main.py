from fastapi import FastAPI
from app.routes.insights import router as insights_router
from app.routes.simulations import router as simulations_router

app = FastAPI(title="DEFRAG Scaffold API")
app.include_router(insights_router)
app.include_router(simulations_router)


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}
