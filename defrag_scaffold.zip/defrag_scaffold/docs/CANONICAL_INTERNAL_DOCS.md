# DEFRAG — Canonical Internal Documentation (v1 Unified)

## Purpose
This document defines the full logical system in one place.

Goals:
- stable
- testable
- explainable
- buildable

This is the source of truth.

## 1. Core system overview
DEFRAG is a relational reasoning system.

It uses:
- people
- relationships
- events
- timing
- structured interpretation

It does not:
- predict the future
- define identity
- replace professional judgment

## 2. Ontology
### Person
- id
- name
- birth_date
- birth_time (optional)
- birth_location (optional)
- data_confidence (exact / partial / unknown)

### Relationship
- person_a
- person_b
- type
- strength (optional)

### FamilySystem
- connected group of people
- multi-generation

### Event
- participants
- description
- timestamp
- tags

### SymbolicProfile
- derived from birth data
- used as prior only

### TimingWindow
- low / moderate / high pressure

### LatentState
- pressure
- openness
- defensiveness
- trust

### Pattern
- repeated interaction dynamic

### Insight
- what is happening
- what it is causing
- what to try next

### SimulationRun
- test interaction paths

### ConfidenceScore
- low / medium / high

### EvidenceLink
- events
- patterns
- timing

## 3. Reasoning contract
Every request follows this sequence:
1. Intake
2. Situation parsing
3. Context retrieval
4. Timing evaluation
5. Structured synthesis
6. Safety check
7. Response generation
8. Optional actions
9. Insight storage
10. Learning loop

### Structured synthesis
System must internally answer:
- what may be happening (user)
- what may be happening (other)
- what is happening between
- what timing suggests
- what help is needed

## 4. Evidence model
Priors (weaker):
- birth-based profiles

Evidence (stronger):
- events
- patterns
- user feedback

Rules:
- increase confidence when patterns repeat and signals agree
- decrease confidence when data is missing or signals conflict
- avoid certainty without evidence

## 5. Family system model
Graph structure:
- nodes = people
- edges = relationships

Rules:
1. Closer = stronger influence
2. Repetition = higher confidence
3. Influence weakens across generations
4. People can diverge from family
5. Real behavior overrides assumptions

## 6. Simulation model
Purpose:
- test interaction
- prepare communication

Perspectives:
- self
- other
- relationship

Output:
- tension points
- openings
- phrasing options

Constraints:
- avoid certainty
- stay grounded

## 7. Language rules
Tone:
- calm
- neutral
- clear

Avoid:
- absolute claims
- identity labels
- diagnosis

Prefer:
- may
- could
- you might

## 8. Data flow
Input:
- user message
- event
- relationship context

Process:
- retrieve context
- evaluate timing
- build synthesis

Output:
- insight
- optional simulation

Store:
- insight
- pattern
- feedback

## 9. API + proof layer
Core rule:
The API does not return freeform AI output alone.

It returns:
- structured reasoning objects
- user-facing insight
- confidence information
- proof information

Main API objects:
- RequestContext
- StructuredSynthesis
- InsightResponse
- ProofObject
- SimulationResponse

Main endpoints:
- POST /api/v1/insights
- POST /api/v1/simulations
- GET /api/v1/insights/{id}/proof
- POST /api/v1/events
- GET /api/v1/timeline

Proof display rules:
Show only:
1. What was observed
2. What pattern may fit
3. What timing may be contributing
4. What remains uncertain

Do not show:
- internal chain-of-thought
- hidden system mechanics
- technical inference language by default
