# Quick Testing

## Goal
Validate that the contract is stable and the reasoning remains grounded.

## In Colab / AI Studio / Stax
1. Paste one RequestContext JSON.
2. Paste the required output shape.
3. Ask the model to fill the shape exactly.
4. Validate:
   - all required keys exist
   - evidence maps to actual input
   - uncertainty is explicit
   - no fixed personality labels
   - no certainty claims without evidence

## Working looks like
- calm language
- both perspectives are present
- proof is inspectable
- next steps are realistic
- pattern labels stay modest and descriptive

## Not working looks like
- motive stated as fact
- hidden assumptions added
- freeform prose without proof
- identity labels
- deterministic claims
