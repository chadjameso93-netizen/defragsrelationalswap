# DEFRAG Implementation Scaffold

This scaffold provides a stable starting point for the DEFRAG platform.

Included:
- canonical internal docs
- JSON Schemas for API contracts
- TypeScript interfaces
- Pydantic models
- example FastAPI routes
- example frontend API client types

This is a build scaffold, not a finished production app.
