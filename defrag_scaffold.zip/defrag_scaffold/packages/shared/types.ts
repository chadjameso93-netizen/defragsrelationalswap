export type DataConfidence = "exact" | "partial" | "unknown";
export type RelationshipType =
  | "parent"
  | "child"
  | "sibling"
  | "partner"
  | "colleague"
  | "friend"
  | "extended_family"
  | "other";
export type RequestedMode = "insight" | "simulation" | "phrasing" | "timing";
export type ConfidenceLevel = "low" | "medium" | "high";
export type Tone = "calm" | "neutral" | "soft" | "direct";

export interface PersonRef {
  id: string;
  name: string;
  birth_date?: string | null;
  birth_time?: string | null;
  birth_location?: string | null;
  data_confidence: DataConfidence;
}

export interface TargetPersonRef extends PersonRef {
  relationship_type: RelationshipType;
}

export interface RelationshipRef {
  id?: string;
  type?: RelationshipType;
  strength?: number;
}

export interface FamilyContextPerson {
  id: string;
  name: string;
  relationship_type: string;
}

export interface EventItem {
  timestamp: string;
  type: "interaction" | "conflict" | "withdrawal" | "repair" | "conversation" | "decision" | "other";
  description: string;
  tags?: string[];
}

export interface RequestContext {
  user: PersonRef;
  target_person?: TargetPersonRef;
  relationship?: RelationshipRef;
  family_context?: FamilyContextPerson[];
  recent_events: EventItem[];
  user_request: string;
  requested_mode: RequestedMode;
  draft_phrase?: string;
  preferred_tone?: Tone;
}

export interface StructuredSynthesis {
  user_experience: string;
  other_experience: string;
  dynamic_between: string;
  timing_assessment: string;
  help_needed: string;
  confidence_level: ConfidenceLevel;
}

export interface Insight {
  what_may_be_happening: string;
  what_it_may_be_causing: string;
  what_to_try_next: string[];
  tone: Tone;
}

export interface PatternCandidate {
  name: string;
  confidence: ConfidenceLevel;
}

export interface ProofObject {
  evidence_used: string[];
  pattern_candidates: PatternCandidate[];
  timing_notes: string[];
  uncertainty_notes: string[];
  confidence_reason: string;
}

export interface SimulationResponse {
  likely_tension_points: string[];
  possible_openings: string[];
  phrasing_options: string[];
  timing_options: string[];
  confidence_level: ConfidenceLevel;
}

export interface InsightApiResponse {
  structured_synthesis: StructuredSynthesis;
  insight: Insight;
  proof: ProofObject;
}

export interface SimulationApiResponse {
  structured_synthesis: StructuredSynthesis;
  simulation: SimulationResponse;
  proof: ProofObject;
}
